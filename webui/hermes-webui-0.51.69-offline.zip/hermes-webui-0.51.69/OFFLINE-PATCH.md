# Офлайн-сборка Hermes WebUI v0.51.69

Исходник: https://github.com/nesquena/hermes-webui/archive/refs/tags/v0.51.69.zip (15.05.2026),
подобран под Hermes Agent v0.13.0 (2026.5.7): последняя версия WebUI до релиза агента v2026.5.16.

Изменения относительно оригинала — только для работы без интернета:

1. `static/vendor/` — библиотеки, которые оригинал грузит из CDN:
   prismjs 1.29.0, katex 0.16.22 (со шрифтами), xterm 5.3.0 + addon-fit 0.8.0 + addon-web-links 0.9.0
   (целиком из npm), mermaid 10.9.3, pdfjs-dist 4.9.155 (нужные файлы), js-yaml 4.1.0 (cdnjs).
   Хеши SRI из index.html совпали с файлами — это те же байты, что на CDN.
2. `static/index.html`, `static/boot.js`, `static/ui.js` — ссылки `https://cdn.jsdelivr.net/npm/…`
   и `https://cdnjs.cloudflare.com/ajax/libs/…` заменены на `static/vendor/npm/…` и `static/vendor/cdnjs/…`.
3. `api/routes.py` — в `_STATIC_MIME` добавлены `mjs` (application/javascript) и `ttf`,
   иначе браузер не выполнит модули pdf.js, отданные как text/plain.
